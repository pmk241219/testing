
let mobileMenu = document.querySelector('.mobile-menu')

document.querySelector('#hamburger').onclick = () =>{
    mobileMenu.classList.toggle('show')
}
